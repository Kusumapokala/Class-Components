import React,{Component} from "react";
export default class Footer extends Component{
    render(){
        return(
            <footer>
                <div>
                    <img src='https://www.achieversit.com/assets/images/logo-white.png' alt="logo"/>
                </div>
                <div>
                <h3>COMPANY</h3>
                <p>home</p>
                <p>placements</p>
                <p>Corporate Training</p>
                <p>Contact Us</p>
                </div>
                <div>
                <h3>TRENDING COURSES</h3>
            <p>UIdevelopment Course</p>
            <p>Angular js Course</p>
            <p>react js Course</p>
            <p>Digital Marketing Course</p>
            <p>Python Course</p>
            </div>
            <div>
            <h3>CONTACT INFO</h3>
            <p></p>
            <p>#63, 1st Floor, 16th Main, 8th Cross,BTM 1st Stage, Bangalore, India - 560029</p>
            <p>India: +91 8431-040-457</p>
            <p>info@achieversit.com</p>
            </div>
               
            </footer>
        )
    }

}